
from flask import Flask, render_template, redirect, url_for, flash
import federation
import secure_partition
import os

app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = "supersecurekey"

@app.route('/')
def index():
    nodes = federation.get_node_status()
    ready = federation.is_federation_ready()
    description = federation.describe_federation()
    mounted = False

    if ready:
        mounted = secure_partition.mount_secure_partition()
        if mounted:
            flash("✅ Secure partition mounted successfully!", "success")
        else:
            flash("❌ Mount failed. No encrypted data.", "danger")
    else:
        flash("⚠️ Federation not ready. Cannot mount partition.", "warning")

    return render_template('index.html', nodes=nodes, desc=description, mounted=mounted)

if __name__ == '__main__':
    if not os.path.exists("secure_data.enc"):
        secure_partition.encrypt_data("Encrypted data from Smart City/Enterprise systems.")
    print("📡 Starting Federated FS Web Server on http://localhost:5000")
    app.run(debug=True)
