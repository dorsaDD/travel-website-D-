
import os
import json
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from base64 import b64encode, b64decode

SECURE_FILE = "secure_data.enc"
DECRYPTED_FILE = "mounted_data.txt"
KEY_FILE = "encryption_key.bin"

def generate_key():
    key = get_random_bytes(16)
    with open(KEY_FILE, "wb") as f:
        f.write(key)

def load_key():
    if not os.path.exists(KEY_FILE):
        generate_key()
    with open(KEY_FILE, "rb") as f:
        return f.read()

def encrypt_data(data):
    key = load_key()
    cipher = AES.new(key, AES.MODE_EAX)
    ciphertext, tag = cipher.encrypt_and_digest(data.encode())
    file_data = {
        "nonce": b64encode(cipher.nonce).decode(),
        "tag": b64encode(tag).decode(),
        "ciphertext": b64encode(ciphertext).decode()
    }
    with open(SECURE_FILE, "w") as f:
        json.dump(file_data, f)

def decrypt_data():
    if not os.path.exists(SECURE_FILE):
        return None
    key = load_key()
    with open(SECURE_FILE, "r") as f:
        file_data = json.load(f)
    try:
        cipher = AES.new(key, AES.MODE_EAX, nonce=b64decode(file_data["nonce"]))
        decrypted = cipher.decrypt_and_verify(b64decode(file_data["ciphertext"]), b64decode(file_data["tag"]))
        return decrypted.decode()
    except Exception as e:
        print(f"Decryption error: {e}")
        return None

def mount_secure_partition():
    decrypted = decrypt_data()
    if decrypted:
        with open(DECRYPTED_FILE, "w") as f:
            f.write(decrypted)
        return True
    return False
