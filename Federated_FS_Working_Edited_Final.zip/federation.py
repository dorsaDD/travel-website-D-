
FEDERATED_NODES = {
    "SmartCity_Node1": {"type": "MCU", "language": "TOIT", "container": "Jaguar", "status": True},
    "SmartBuilding_Node2": {"type": "MPU", "language": "Python", "container": "Docker", "status": True},
    "Enterprise_Node3": {"type": "MCU", "language": "TOIT", "container": "Jaguar", "status": True}
}

def is_federation_ready():
    return all(node["status"] for node in FEDERATED_NODES.values())

def get_node_status():
    return FEDERATED_NODES

def describe_federation():
    return {
        key: f"{val['type']} | {val['language']} | {val['container']}"
        for key, val in FEDERATED_NODES.items()
    }
