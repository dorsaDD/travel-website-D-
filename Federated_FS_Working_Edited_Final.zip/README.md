
# Federated File System (Enhanced)

This project demonstrates a secure, scenario-aware federated file system designed for **Smart Cities**, **Smart Buildings**, and **Enterprises**, integrating **MCU** and **MPU** edge devices with varied software environments (TOIT, Python) and container runtimes (Jaguar, Docker).

---

## 🚀 Features

- **Secure Partition with AES Encryption**
- **Federation Across Diverse Edge Nodes**
- **Supports Smart City, Building, and Enterprise Scenarios**
- **Container Runtime Awareness (Docker, Jaguar)**
- **MCU (ESP32 / TOIT Simulation) & MPU (Raspberry Pi / Docker)**
- **Flask Web Dashboard with Status Monitoring**

---

## 🗂 Project Structure

```
/app.py                  # Main Flask app
/federation.py           # Federation logic with node types
/secure_partition.py     # Secure partition with AES encryption
/jaguar_simulation.py    # ESP32 simulation for TOIT/Jaguar node
/templates/index.html    # Web UI
/static/style.css        # UI styling
/Dockerfile              # For MPU deployment via Docker
/requirements.txt        # Python dependencies
```

---

## 🧠 Federation Model

Each node is defined with:

- `type`: MCU or MPU
- `language`: TOIT or Python
- `container`: Jaguar or Docker
- `status`: Ready/Not Ready

Example (from `federation.py`):
```python
FEDERATED_NODES = {
  "SmartCity_Node1": {"type": "MCU", "language": "TOIT", "container": "Jaguar", "status": True},
  ...
}
```

---

## 🛡 Secure Partition

- Uses AES-128 encryption (`Crypto.Cipher`)
- `secure_data.enc`: Encrypted output
- `mounted_data.txt`: Mounted (decrypted) data
- Mounted only when all nodes are `Ready`

---

## 🖥 Running the Project

### Prerequisites
- Python 3.10+
- `pip install -r requirements.txt`

### Run Locally
```bash
python app.py
```

### Build & Run with Docker (MPU)
```bash
docker build -t federated-fs .
docker run -p 5000:5000 federated-fs
```

---

## 🐆 Simulating Jaguar + TOIT Node (ESP32)

```bash
python jaguar_simulation.py
```

Generates `jaguar_node_status.json` to emulate an ESP32 edge node.

---

## 📊 Dashboard

Visit `http://localhost:5000` to view:
- Node readiness
- Federation structure
- Secure partition mount status

---

## 📜 License

MIT License
